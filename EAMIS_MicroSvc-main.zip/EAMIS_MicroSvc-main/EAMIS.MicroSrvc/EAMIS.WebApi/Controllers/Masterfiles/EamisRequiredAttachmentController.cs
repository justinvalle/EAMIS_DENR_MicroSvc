﻿using EAMIS.Common.DTO.Masterfiles;
using EAMIS.Core.ContractRepository.Masterfiles;
using EAMIS.Core.Response.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EAMIS.WebApi.Controllers.Masterfiles
{
    [Route("api/[controller]")]
    [ApiController]
    public class EamisRequiredAttachmentController : ControllerBase
    {
        IEamisRequiredAttachmentsRepository _eamisRequiredAttachmentsRepository;
        public EamisRequiredAttachmentController(IEamisRequiredAttachmentsRepository eamisRequiredAttachmentsRepository)
        {
            _eamisRequiredAttachmentsRepository = eamisRequiredAttachmentsRepository;
        }

        [HttpGet("list")]
        public async Task<ActionResult<EamisRequiredAttachmentsDTO>> List([FromQuery] EamisRequiredAttachmentsDTO filter, [FromQuery]PageConfig config)
        {
            if (filter == null)
                filter = new EamisRequiredAttachmentsDTO();
            return Ok(await _eamisRequiredAttachmentsRepository.List(filter,config));
        }
        [HttpPost("Add")]
        public async Task<ActionResult<EamisRequiredAttachmentsDTO>> Add([FromBody] EamisRequiredAttachmentsDTO item)
        {
            if (item == null)
                item = new EamisRequiredAttachmentsDTO();
            return Ok(await _eamisRequiredAttachmentsRepository.Insert(item));
        }
        [HttpPut("Edit")]
        public async Task<ActionResult<EamisRequiredAttachmentsDTO>> Edit([FromBody] EamisRequiredAttachmentsDTO item)
        {
            if (item == null)
                item = new EamisRequiredAttachmentsDTO();
            return Ok(await _eamisRequiredAttachmentsRepository.Update(item));
        }
        [HttpPost("Delete")]
        public async Task<ActionResult<EamisRequiredAttachmentsDTO>> Delete([FromBody] EamisRequiredAttachmentsDTO item)
        {
            if (item == null)
                item = new EamisRequiredAttachmentsDTO();
            return Ok(await _eamisRequiredAttachmentsRepository.Delete(item));
        }
    }
}
