﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAMIS.Common.DTO
{
    public class EamisRegionDTO
    {
        public string PsgCode { get; set; }
        public string RegionDescription { get; set; }
        public int RegionCode { get; set; }
    }
}
