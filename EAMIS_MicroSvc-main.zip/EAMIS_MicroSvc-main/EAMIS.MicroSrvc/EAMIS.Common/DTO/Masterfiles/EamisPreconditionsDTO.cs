﻿namespace EAMIS.Common.DTO.Masterfiles
{
    public class EamisPreconditionsDTO
    {
        public int Id { get; set; }
        public int Parent_Id { get; set; }
        public string Precondition_Description { get; set; }
    }
}
