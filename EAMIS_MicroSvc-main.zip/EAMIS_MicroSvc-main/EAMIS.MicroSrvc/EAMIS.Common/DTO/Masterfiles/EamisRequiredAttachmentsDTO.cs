﻿namespace EAMIS.Common.DTO.Masterfiles
{
    public class EamisRequiredAttachmentsDTO
    {
        public int Id { get; set; }
        public string AttachmentTypeDescription { get; set; }
        public bool Is_Required { get; set; }
    }
}
