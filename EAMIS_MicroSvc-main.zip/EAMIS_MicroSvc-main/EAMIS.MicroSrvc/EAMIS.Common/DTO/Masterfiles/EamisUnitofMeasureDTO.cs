﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAMIS.Common.DTO.Masterfiles
{
    public class EamisUnitofMeasureDTO
    {
        public int Id { get; set; }
        public string Short_Description { get; set; }
        public string Uom_Description { get; set; }
    }
}
