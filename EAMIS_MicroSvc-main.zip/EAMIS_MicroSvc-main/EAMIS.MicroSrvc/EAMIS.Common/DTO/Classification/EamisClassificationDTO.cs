﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAMIS.Common.DTO.Classification
{
    public class EamisClassificationDTO
    {
        public int Id { get; set; }
        public string NameClassification { get; set; }
    }
}
