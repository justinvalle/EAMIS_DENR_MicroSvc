﻿using EAMIS.Common.DTO.Masterfiles;
using EAMIS.Core.Response.DTO;
using System.Threading.Tasks;

namespace EAMIS.Core.ContractRepository.Masterfiles
{
    public interface IEamisRequiredAttachmentsRepository
    {
        Task<DataList<EamisRequiredAttachmentsDTO>> List(EamisRequiredAttachmentsDTO filter, PageConfig config);
        Task<EamisRequiredAttachmentsDTO> Insert(EamisRequiredAttachmentsDTO item);
        Task<EamisRequiredAttachmentsDTO> Update(EamisRequiredAttachmentsDTO item);
        Task<EamisRequiredAttachmentsDTO> Delete(EamisRequiredAttachmentsDTO item);
    }
}
