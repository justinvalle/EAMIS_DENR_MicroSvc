﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAMIS.Core.Domain.Entities
{
    public class EAMISENVIRONMENTALIMPACTS
    {
        public int ID { get; set; }
        public string IMPACT_DESCPRIPTION { get; set; }
    }
}
