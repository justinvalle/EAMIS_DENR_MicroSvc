﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAMIS.Core.Domain.Entities
{
    public class EAMISFUNDSOURCE
    {
        [Key]
        public int ID { get; set; }
        public string CODE { get; set; }
        public int GENERAL_FUND_SOURCE_ID { get; set; }
        public string FINANCING_SOURCE { get; set; }
        public string AUTHERIZATION { get; set; }
        public string FUND_CATEGORY { get; set; }
        public EAMISGENERALFUNDSOURCE GENERALFUNDSOURCE { get; set; }
    }
}
